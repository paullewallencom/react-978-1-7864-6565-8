import React from 'react';

export const GroupsActiveHeader = () => (
  <h1>Active Groups</h1>
);

export default GroupsActiveHeader;
