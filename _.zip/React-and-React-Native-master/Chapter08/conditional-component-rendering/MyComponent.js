import React from 'react';

// The world's simplest component...
export default () => (
  <p>My component...</p>
);
