import React from 'react';

export default () => (<h1>Groups Header</h1>);
