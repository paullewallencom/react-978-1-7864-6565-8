import React from 'react';

export const GroupsActiveContent = () => (
  <em>Active groups content...</em>
);

export default GroupsActiveContent;
