import React from 'react';
import { render } from 'react-dom';

import MyFeature from './MyFeature';

render(
  (<MyFeature />),
  document.getElementById('app')
);
