require('babel-core/register');
require('./server');
