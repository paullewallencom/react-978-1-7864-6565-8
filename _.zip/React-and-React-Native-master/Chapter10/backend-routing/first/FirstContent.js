import React from 'react';

export default () => (<p>First</p>);
