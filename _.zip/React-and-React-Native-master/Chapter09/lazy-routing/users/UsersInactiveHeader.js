import React from 'react';

export const UsersInactiveHeader = () => (
  <h1>Inactive Users</h1>
);

export default UsersInactiveHeader;
