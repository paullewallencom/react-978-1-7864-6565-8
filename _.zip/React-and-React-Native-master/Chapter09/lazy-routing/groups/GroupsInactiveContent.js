import React from 'react';

export const GroupsInactiveContent = () => (
  <em>Inactive groups content...</em>
);

export default GroupsInactiveContent;
