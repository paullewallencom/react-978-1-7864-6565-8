import React from 'react';
import { render } from 'react-dom';

import MyInput from './MyInput';

render(
  (<MyInput />),
  document.getElementById('app')
);
