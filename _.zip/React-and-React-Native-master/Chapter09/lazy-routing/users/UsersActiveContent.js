import React from 'react';

export const UsersActiveContent = () => (
  <em>Active users content...</em>
);

export default UsersActiveContent;
