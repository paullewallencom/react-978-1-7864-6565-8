import React from 'react';
import { Link } from 'react-router';

export default () => (
  <Link to="first">To first page</Link>
);
