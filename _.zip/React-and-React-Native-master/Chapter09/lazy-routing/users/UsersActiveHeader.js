import React from 'react';

export const UsersActiveHeader = () => (
  <h1>Active Users</h1>
);

export default UsersActiveHeader;
