import React from 'react';

export const UsersInactiveContent = () => (
  <em>Inactive users content...</em>
);

export default UsersInactiveContent;
