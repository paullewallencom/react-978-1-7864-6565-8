import React from 'react';

export const GroupsInactiveHeader = () => (
  <h1>Inactive Groups</h1>
);

export default GroupsInactiveHeader;
