import React from 'react';

export default () => (
  <p>Hello Route!</p>
);
