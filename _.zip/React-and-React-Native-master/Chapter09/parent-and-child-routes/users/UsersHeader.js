import React, { Component } from 'react';

export default () => (<h1>Users Header</h1>);
