import React from 'react';

export default () => (<p>Groups content...</p>);
