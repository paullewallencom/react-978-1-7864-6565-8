import first from './scenes/first';
import second from './scenes/second';
import third from './scenes/third';

export default [
  first,
  second,
  third,
];
