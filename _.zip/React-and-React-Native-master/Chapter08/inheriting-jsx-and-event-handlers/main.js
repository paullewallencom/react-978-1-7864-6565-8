import React from 'react';
import { render } from 'react-dom';

import MyComponent from './MyComponent';

render((
  <section>
    <MyComponent />
  </section>
  ),
  document.getElementById('app')
);
